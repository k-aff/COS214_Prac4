#include "FertilizedSoil.h"

double FertilizedSoil::harvestCrops(){
    return 0.5;   
}

double FertilizedSoil::rain(){
    return 10.2;
}

string FertilizedSoil::getName(){
    return "Fertilized";
}