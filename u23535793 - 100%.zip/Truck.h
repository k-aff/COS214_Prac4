#ifndef TRUCK_H
#define TRUCK_H

class Truck
{
    public:
        virtual void startEngine() = 0; 
}; 

#endif 