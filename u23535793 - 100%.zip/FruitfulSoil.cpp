#include "FruitfulSoil.h"

double FruitfulSoil::harvestCrops(){
    return 0.3;   
}

double FruitfulSoil::rain(){
    return 10;
}

string FruitfulSoil::getName(){
    return "Fruitful";
}