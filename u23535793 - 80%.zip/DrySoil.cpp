#include "DrySoil.h"

double DrySoil::harvestCrops(){
    return 0.1;   
}

double DrySoil::rain(){
    return 15;
}

string DrySoil::getName(){
    return "Dry"; 
}