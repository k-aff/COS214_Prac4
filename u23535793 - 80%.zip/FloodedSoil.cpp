#include "FloodedSoil.h"

double FloodedSoil::harvestCrops(){
    return 0;   
}

double FloodedSoil::rain(){
    return 0;
}

string FloodedSoil::getName(){
    return "Flooded";
}